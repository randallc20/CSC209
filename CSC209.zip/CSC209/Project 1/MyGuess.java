/* Mark Donohue & Chris Randall
 * File: MyGuess.java
 * Project 1
 * Program randomly selects a number between 1 and 100, allows user to input guesses, 
 * and prints relevant information upon completion.
 */

import java.util.Scanner;

public class MyGuess {
	public static void main(String[] args) {
		int myNumber = (int)(Math.random() * 100);
		int count = 0;
		System.out.println("I'm thinking of a number between 1 and 100.");
		System.out.println("Enter a guess:");
		Scanner input = new Scanner(System.in);
		
		while (true) {
			count ++;
			int guess = input.nextInt();
			if (guess == myNumber) {
				System.out.println("Congratulations! You got it in " + count + " attempts!");
				break;
			} else if (guess < 1 || guess > 100) {
				System.out.println("Error: Guess must be between 1 and 100. You lose a guess!");
			} else if (guess < myNumber) {
				System.out.println("Too small.");
			} else {
				System.out.println("Too large.");
			} if (count == 7) {
				System.out.println("You have exceeded the maximum number of allowable guesses. You lose!");
				System.exit(0);
			}							
		}		
	}
}