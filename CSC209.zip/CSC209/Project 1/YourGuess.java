/*
Chris Randall + Mark Donohue
File: YourGuess.java
Project 1
Description: the user thinks of a number between 1 and 100 - then the computer tries to guess the number. 
The user tells the computer if the guess is too high or too low - this prompts the computer to guess again until
the correct number is guessed.
*/

import java.util.Scanner;

public class CSC209Project1 {


    public static void main(String[] args) {
        System.out.println("Choose a number between 1 and 100 and the computer will try to guess your number");
        System.out.println("'too small' and 'too large' are acceptable responses to the computer's guess");
        System.out.println("Also when the computer guesses your number type: 'correct', and if you ever want to end the game type: 'quit'");
        System.out.println("Now input a number between 1 and 100:");
        Scanner input = new Scanner(System.in);
        System.out.println("");
        int count = 0; 
        int guess = 50;
        int num = input.nextInt();
        int upperLimit = 100;
        int lowerLimit = 1;
        if (num < 1 || num > 100) {
            System.out.println("Your number is not in the correct range of numbers");
            System.out.println("The game will now quit");
            System.exit(0);
        }
        //System.out.println("The first guess is: " + guess);
        while (count < 8){
        //this while loop contains the statements that register user input and change the bounds for the guesses
            count++;
            String response = input.nextLine().toUpperCase();
            if (response.equals("TOO LARGE")){
                upperLimit = guess;
                guess = (upperLimit + lowerLimit)/2;
            }
            else if (response.equals("TOO SMALL")){
                lowerLimit = guess;
                guess = (upperLimit + lowerLimit)/2;
            }
            else if (response.equals("QUIT")){
                System.exit(0);
            }
            else if (response.equals("CORRECT")){
                System.out.println("Congrats :) you won");
                System.out.println("The amount of guesses was:" + count);
                System.exit(0);
            }
            
            System.out.println("The new guess is: " + guess);
            
        }
        System.out.println("You Cheated!!");
    }
    
}
