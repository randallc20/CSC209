
public interface ViewInformer {
	public void panelPressed(AbstractPanel panel);
}
