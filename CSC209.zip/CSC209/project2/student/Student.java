package student;

/* 
Student.java
Manage a student's name and test scores.
*/

public class Student {

    // Class variable for default number of scores

    static public final int DEFAULT_NUM_SCORES = 3;

    //Instance variables
    //Each student object has a name and a set of test scores

    private String name;             
    private int[] scores;             

    //Constructors
    /**
     * default student constructor 
     * @param nm
     * @param numScores 
     */
    public Student(String nm, int numScores){
        name = nm;
        scores = new int[numScores];
    }
    /**
     * constructor
     * @param nm 
     */
    public Student (String nm){
        this(nm, DEFAULT_NUM_SCORES);
    }
    /**
     * constructor
     * 
     */
    public Student(){
        this("", DEFAULT_NUM_SCORES);
    }

    // String representation
    /**
     * returns string
     * @return 
     */
    public String toString(){
        String str;
        str = "Name:    " + name  + "\nScores:\n";
        for (int score : scores)
             str += score + "\n";
        str += "Average: " + getAverage();
        return str;
    }  

    // Accessors and mutators
    /**
     * sets name to value
     * @param nm 
     */
    public void setName(String nm){
         name = nm;
    }
    /**
     * returns name
     * @return 
     */
    public String getName(){
        return name;
    }
    /**
     * sets score to new score
     * @param i
     * @param newScore 
     */
    public void setScore(int i, int newScore){
        scores[i - 1] = newScore;
    }
    /**
     * returns the score and checks that the index is within range
     * @param i
     * @throws IllegalArgumentException if i less than 1 or i greater than
     * @return 
     */
    public int getScore(int i){
   if (i < 1 || i >= scores.length)
      throw new RuntimeException("i must be between " +
                                 "1 and " +
                                 scores.length);
   return scores[i - 1];
}

    /**
     * returns the length of the array
     * @return 
     */
    public int getNumScores(){
        return scores.length;
    }
   
    // Other methods
    /**
     * calculates and returns the average of the values
     * also throws exception for when you try to divide by 0
     * @return 
     */
    public double getAverage(){
        int sum = 0;
        for (int i = 0; i < scores.length; i++){
            sum += scores[i];
        }
        if (scores.length == 0)
            throw new ArithmeticException("you can not divide by zero");
        return sum/scores.length;
    }
    /**
     * returns and calculates the high score 
     * @return 
     */
    public int getHighScore(){
        int max = scores[0];
        for (int i = 1; i < scores.length; i++){
            if (scores[i] > max)
                max = scores[i];
        }
        return max;
    }
}