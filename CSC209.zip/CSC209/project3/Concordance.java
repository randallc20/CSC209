/*
 * Chris Randall
 * Concordance.java
 * makes a map of all the words in the file, then counts how many times 
 * each word appears in the file
 */

import java.io.*;
import java.util.*;
/*

*/
public class Concordance {
    
    public static void main(String[] args){
        
       int lineCount = 0;
       TreeMap<String,Integer> map = new TreeMap<String,Integer>();
       
       try{
            File inputFile = new File("command.txt");
            Scanner input = new Scanner(inputFile);
            while (input.hasNextLine()){
                lineCount++;
                String[] myWords = input.nextLine().split(" ");
                for (String s : myWords){
                    if (!map.containsKey(s)){
                        map.put(s,1);
                    }
                    else{
                        map.put(s, map.get(s) + 1);
                    }
                }
                
            }
            for (String s : map.keySet()){
                String key = s.toString();
                String value = map.get(s).toString();
                System.out.println(key + " " + value);
            }
        }catch (IOException e){
            System.out.println(e.toString());
        }

        
    }
    
}