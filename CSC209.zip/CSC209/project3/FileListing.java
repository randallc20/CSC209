/**
 * Chris Randall
 * Lambert 
 * reads lines of text from its input file and writes them to its output file, 
 * producing a �listing� in which each line is numbered (counting from 1) and
 * the line numbers are right-justified in 5 columns
 */
import java.io.*;
import java.util.Scanner;

public class FileListing {
    public static void main(String[] args){
        
       int lineCount = 0;
       try{
            File inputFile = new File("command.txt");
            PrintWriter output = new PrintWriter("listing.txt");
            Scanner input = new Scanner(inputFile);
            while (input.hasNextLine()){
                lineCount++;
                output.printf("%5d %s\n", lineCount, input.nextLine());
                
            }
            
            //System.out.println("Line Count = " + lineCount);
        }catch (IOException e){
            System.out.println(e.toString());
        }

        
    }
    
}