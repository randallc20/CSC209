import java.io.*;
/*
 * Chris Randall
 * FileStats.java
 * counts the number of lines, words, and characters in its input 
 * file and outputs these statistics, appropriately labeled, to the terminal
 */

import java.io.*;
import java.util.Scanner;
/*
 * reads in the file and breaks it up into lines and counts the words by sending them into an array
*/
public class FileStats {
    
    public static void main(String[] args){
        
       int lineCount = 0;
       int wordCount = 0;
       int charCount = 0;
       try{
            File inputFile = new File("command.txt");
            Scanner input = new Scanner(inputFile);
            while (input.hasNextLine()){
                lineCount++;
                String[] myWords = input.nextLine().split(" ");//makes array here splitting by spaces for words
                wordCount += myWords.length;
                for (String s : myWords){
                    charCount += s.length();
                }
                
            }
            System.out.println("Line Count = " + lineCount);
            System.out.println("Word Count = " + wordCount);
            System.out.println("Character Count = " + charCount);
        }catch (IOException e){
            System.out.println(e.toString());
        }

        
    }
    
}