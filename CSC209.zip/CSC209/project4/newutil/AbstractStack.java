/*
 * Chris Randall
 */
package newutil;

import java.util.*;

abstract public class AbstractStack<E> extends AbstractCollection<E> 
                           implements TrueStack<E>{

    abstract public E peek();

    abstract public E pop();
    /*
    * This method checks if two stacks are equal
    * @param takes object other as a parameter
    * @return true or false 
    */
    public boolean equals(Object other){
        if (this == other) return true;
        if (! (other instanceof TrueStack)) return false;
        TrueStack otherStack = (TrueStack)other;
        if (this.size() != otherStack.size()) return false;
        Iterator otherIter = otherStack.iterator();
        for (E thisElement : this)
            if (! thisElement.equals(otherIter.next()))
                return false;
        return true;

    }

    abstract public void push(E newElement);

    public boolean add(E newElement){
        this.push(newElement);
        return true;
    }
    
}

