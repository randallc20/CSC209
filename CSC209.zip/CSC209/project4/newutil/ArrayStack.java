/**
 * Chris Randall 
 */
package newutil;

import java.util.*;

/**
 * Array implementation of a stack.  Most methods are O(1) runtime complexity 
 * with mutator method being O(n) in the worse case scenario.
 * @author chris
 * @param <E> 
 */

public class ArrayStack<E> extends AbstractStack<E>{

    private List<E> list;

    public ArrayStack(){
        list = new ArrayList<E>();
    }
    
    /**
     * creates a clone
     * @param col 
     */
    public ArrayStack(Collection<E> col){
        this();
        this.addAll(col);
    }
    /**
     * 
     * @return 
     */
    public E peek(){
        E peeked = null;
        try{
            peeked = list.get(list.size() - 1);
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println(e.toString());
        }
        return peeked;
    }
    /**
     * 
     * @return 
     */
    public E pop(){
        E popped = null;
        try{
            popped = list.remove(list.size() - 1);
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println(e.toString());
        }
        return popped;
    }
    /**
     * 
     * @param newElement 
     */
    public void push(E newElement){
        list.add(newElement);
    }
    /**
     * 
     * @return 
     */
    public int size(){
        return list.size();
    }  
    /**
     * 
     * @return 
     */
    public Iterator<E> iterator(){
        return new StackIterator<E>(list.iterator());
    }
    /**
     * 
     * @param <E> 
     */
    private class StackIterator<E> implements Iterator<E>{

        private Iterator<E> iter;
        private StackIterator(Iterator<E> iter){
            this.iter = iter;
        }

        
        public boolean hasNext(){
            return iter.hasNext();
        }

        public E next(){
            return iter.next();
        }

        public void remove(){
            throw new UnsupportedOperationException(
              "remove not supported by stacks");

        }
    }

    
}
