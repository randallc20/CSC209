/*
 * Chris Randall
 */
package newutil;

/**
 *
 * @author chris
 */
import java.util.*;
import newutil.TrueStack;
import newutil.ArrayStack;

public class LinkedStack<E> extends AbstractStack<E>{

    private List<E> list;

    public LinkedStack(){
        list = new LinkedList<E>();
    }
    

    public LinkedStack(Collection<E> col){
        this();
        this.addAll(col);
    }

    public E peek(){
        return list.get(list.size() - 1);
    }

    public E pop(){
        return list.remove(list.size() - 1);
    }

    public void push(E newElement){
        list.add(newElement);
    }

    public int size(){
        return list.size();
    }

    public Iterator<E> iterator(){
        return list.iterator();
    }  
    
}
